﻿using System;

namespace SimpleMvvmToolkitTest
{
    public class MessageTokens
    {
        public const string Test = "TestToken";
    }
}
