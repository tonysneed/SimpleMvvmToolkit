﻿using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("SimpleMvvmToolkit-SL5")]
[assembly: AssemblyDescription("Simple Mvvm Toolkit for Silverlight 5")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Tony Sneed")]
[assembly: AssemblyProduct("SimpleMvvmToolkit-SL5")]
[assembly: AssemblyCopyright("Copyright © Tony Sneed 2013")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Makes this assembly consumable by VB.NET
[assembly: CLSCompliant(true)]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("77f35d41-1bf8-44f2-b852-778761a48e66")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Revision and Build Numbers 
// by using the '*' as shown below:
[assembly: AssemblyVersion("5.5.0.0")]
[assembly: AssemblyFileVersion("5.5.0.0")]
