﻿using System;

namespace $safeprojectname$
{
    // TODO: Add string constants for Views you add to the project

    public class PageNames
    {
        public const string Home = "Home";
        public const string ItemList = "ItemListView";
    }
}
