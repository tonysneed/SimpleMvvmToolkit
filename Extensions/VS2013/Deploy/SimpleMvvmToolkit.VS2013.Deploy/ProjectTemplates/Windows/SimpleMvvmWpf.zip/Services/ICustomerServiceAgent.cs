﻿using System;
using System.Linq;

namespace $safeprojectname$
{
    public interface ICustomerServiceAgent
    {
        Customer CreateCustomer();
    }
}
