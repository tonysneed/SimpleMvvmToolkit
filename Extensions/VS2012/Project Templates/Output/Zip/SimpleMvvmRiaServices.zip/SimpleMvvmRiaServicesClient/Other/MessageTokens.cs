﻿using System;

namespace $safeprojectname$
{
    // Message token constants
    public class MessageTokens
    {
        public const string Navigation = "NavigationMessageToken";
    }
}
